define({
  "_themeLabel": "Rozkládací motiv",
  "_layout_default": "Výchozí rozvržení",
  "_layout_layout1": "Rozvržení 1"
});