define({
  "_widgetLabel": "Ylätunnisteen hallinta",
  "signin": "Kirjaudu sisään",
  "signout": "Kirjaudu ulos",
  "about": "Tietoja",
  "signInTo": "Kirjaudu palveluun",
  "cantSignOutTip": "Toiminto ei ole käytettävissä esikatselutilassa.",
  "more": "lisää"
});