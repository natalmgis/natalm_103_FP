define({
  "_widgetLabel": "Fejléc vezérlő",
  "signin": "Bejelentkezés",
  "signout": "Kijelentkezés",
  "about": "További információ",
  "signInTo": "Bejelentkezés ide:",
  "cantSignOutTip": "Ez a funkció előnézeti módban nem alkalmazható.",
  "more": "több"
});